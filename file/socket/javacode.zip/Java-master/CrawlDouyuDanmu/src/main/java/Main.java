import java.io.IOException;

/**
 * Created by geekgao on 16-1-26.
 */
public class Main {
    public static void main(String[] args) throws IOException {
        Crawl c = new Crawl();
        c.start();
    }
}
