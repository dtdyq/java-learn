# 博客

如果你只是单纯要阅读的话，建议移步CSDN或者oschina上观看，访问速度快很多：

>* CSDN:[我的java&javaweb学习笔记(汇总)](http://blog.csdn.net/h3243212/article/details/50659471)
>* oschina:[我的java&javaweb学习笔记(汇总)](http://my.oschina.net/brianway/blog/614355)


# 目录

- [javase](/blogs/javase)
  - [java基础巩固笔记(1)-反射.md](/blogs/javase/java基础巩固笔记(1)-反射.md)
  - [java基础巩固笔记(2)-泛型.md](/blogs/javase/java基础巩固笔记(2)-泛型.md)
  - [java基础巩固笔记(3)-类加载器.md](/blogs/javase/java基础巩固笔记(3)-类加载器.md)
  - [java基础巩固笔记(4)-代理.md](/blogs/javase/java基础巩固笔记(4)-代理.md)
  - [java基础巩固笔记(4)-实现AOP功能的封装与配置的小框架.md](/blogs/javase/java基础巩固笔记(4)-实现AOP功能的封装与配置的小框架.md)
  - [java基础巩固笔记(5)-多线程之传统多线程.md](/blogs/javase/java基础巩固笔记(5)-多线程之传统多线程.md)
  - [java基础巩固笔记(5)-多线程之共享数据.md](/blogs/javase/java基础巩固笔记(5)-多线程之共享数据.md)
  - [java基础巩固笔记(5)-多线程之线程并发库.md](/blogs/javase/java基础巩固笔记(5)-多线程之线程并发库.md)
  - [java基础巩固笔记(6)-注解.md](/blogs/javase/java基础巩固笔记(6)-注解.md)
- [javaweb](/blogs/javaweb)
  - [javaweb入门笔记(1)-Tomcat.md](/blogs/javaweb/javaweb入门笔记(1)-Tomcat.md)
  - [javaweb入门笔记(2)-http入门.md](/blogs/javaweb/javaweb入门笔记(2)-http入门.md)
  - [javaweb入门笔记(3)-Servlet.md](/blogs/javaweb/javaweb入门笔记(3)-Servlet.md)
  - [javaweb入门笔记(4)-request和response.md](/blogs/javaweb/javaweb入门笔记(4)-request和response.md)
  - [javaweb入门笔记(5)-cookie和session.md](/blogs/javaweb/javaweb入门笔记(5)-cookie和session.md)
  - [javaweb入门笔记(6)-JSP技术.md](/blogs/javaweb/javaweb入门笔记(6)-JSP技术.md)