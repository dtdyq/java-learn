package com.brianway.learning.java.base;

/**
 * Created by Brian on 2016/4/13.
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
