package com.brianway.learning.java.multithread.communication.example16;

/**
 * Created by Brian on 2016/4/14.
 */
public class Tools {
    public static ThreadLocalExt tl = new ThreadLocalExt();
    public static InheritableThreadLocalExt itl = new InheritableThreadLocalExt();
    public static InheritableThreadLocalExt2 itl2 = new InheritableThreadLocalExt2();

}
