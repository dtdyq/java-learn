package com.brianway.learning.java.multithread.meet;

/**
 * Created by Brian on 2016/4/10.
 */

/**
 * P4的小例子
 */
public class printMain {
    public static void main(String[] args) {
        System.out.println(Thread.currentThread().getName());
    }
}

/*
output:
main
 */