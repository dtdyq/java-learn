package com.brianway.learning.java.multithread.communication.example6;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Brian on 2016/4/14.
 */
public class ValueObject {
    public static List list = new ArrayList();
}
